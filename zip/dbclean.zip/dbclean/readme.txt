This serves as an example of how to make a full width widget that has database interactions. 
